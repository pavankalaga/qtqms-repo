<!DOCTYPE html>
<html lang="en" dir="">

<head>
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <!-- font css -->
  <link type="text/css" rel="stylesheet" href="/public/demo/tabler-icons.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/feather.css">
  <!-- <link type="text/css" rel="stylesheet" href="/demo/fontawesome.css}"> -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/material.css">
  <!-- vendor css -->
  <link type="text/css" rel="stylesheet" href="/public/demo/style.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/bootstrap-switch-button.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/datepicker-bs5.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/flatpickr.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/customizer.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/custome.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/new-custom.css">
  <style>
    :root {
      --color-customColor: theme-1;
    }
  </style>
  <link type="text/css" rel="stylesheet" href="/public/demo/custom-color.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/stylecss.css" id="main-style-link">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <style>
    .support-query-form-buttons {
      display: flex;
      justify-content: space-between;
      gap: 10px;
    }

    .support-query-form-buttons button {
      flex: 1;
      padding: 12px 20px;
      border: none;
      border-radius: 5px;
      font-size: 0.9rem;
      font-weight: bold;
      cursor: pointer;
      transition: background-color 0.3s ease, transform 0.2s ease;
    }

    .support-query-form-buttons .support-query-save {
      background-color: #007bff;
      color: #fff;
    }

    .support-query-form-buttons .support-query-save:hover {
      background-color: #0056b3;
      transform: translateY(-2px);
    }

    .support-query-form-buttons .support-query-cancel {
      background-color: #dc3545;
      color: #fff;
    }

    .support-query-form-buttons .support-query-cancel:hover {
      background-color: #c82333;
      transform: translateY(-2px);
    }

    /* Responsive Design */
    @media (max-width: 768px) {
      .support-query-form-buttons {
        flex-direction: column;
      }

      .support-query-form-buttons button {
        width: 100%;
        margin-bottom: 10px;
      }
    }

    .nav-tabs .nav-link-tabs.active {
      background: none;
    }

    li .accordion-button:not(.collapsed)::after {
      background-image: none;
      -moz-transform: rotateZ(45deg);
      -o-transform: rotateZ(45deg);
      -ms-transform: rotateZ(45deg);
      -webkit-transform: rotateZ(45deg);
      transform: rotateZ(180deg);
    }

    li .accordion-button::after {
      background-image: none;
      content: '\f078';
      font-family: "Font Awesome 5 Free";
      font-size: 1rem;
      font-weight: 900;
    }

    li .no-toggle::after {
      background-image: none;
      content: '' !important;

    }

    li .accordion-item {
      border: none;
      border-radius: 0 !important;
      background-color: transparent;
    }

    li .accordion-button:not(.collapsed) {
      color: #FFFFFF;
      background: transparent;
      border-radius: 0;
    }

    li .accordion-button {
      color: #FFFFFF;
      border-bottom: 1px solid #009246;
      border-radius: 0;
      background-color: transparent;
    }

    li .accordion-button:hover {
      background-color: #FFFFFF;
      color: #29357c !important;
      font-weight: 700;
    }

    li .accordion-button:hover a {

      color: #29357c !important;
      font-weight: 700;
    }

    .accordion-item .nav-item .nav-link:hover {
      color: #F2F4F6;
      background-color: #009246;
    }

    li .collapse:not(.show) {
      display: none !important;
    }

    .tr-second-nav {
      background: #010046;
      position: relative;
      max-width: calc(100% - 310px);
      border-radius: 4px;
      left: 255px;
      top: 10px;
      width: 100%;
      z-index: 999;
      transition: all 0.5s ease;
    }

    .fixed-header {
      position: fixed;
      top: 75px !important;
    }

    .tr-second-nav button {
      min-width: 75px;
      border-radius: 4px;
      font-weight: 600;
      min-height: 36px;
    }

    .tr-triple-nav {
      margin: 0 30px 0 255px;
      max-width: calc(100% - 310px);
      border-radius: 4px;
    }

    .tr-username {
      color: #fff;
      font-weight: 600;
      font-size: 19px;
    }

    .logout-icon:hover .fa-right-from-bracket {
      transform: translateX(5px);
      transition: all 0.5s ease;
    }

    body {
      /* font-family: 'Quicksand', sans-serif !important; */
      /* font-weight: 400; */
    }

    .quicksand {
      font-family: "Quicksand", sans-serif;
      font-optical-sizing: auto;
      font-weight: 400;
      font-style: normal;
    }
  </style>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Quicksand:wght@300..700&display=swap" rel="stylesheet">

  <link type="text/css" rel="stylesheet" href="/public/demo/summernote-lite.min.css">
  <link type="text/css" rel="stylesheet" href="/public/demo/dropzone.min.css">
  <script src="/demo/jquery.min.js"></script>
  <link type="text/css" rel="stylesheet" href="/public/demo/nprogress.css">


  <script src="/demo/nprogress.js"></script>
  <link type="text/css" rel="stylesheet" href="/public/demo/responsive.css">
  <!--   <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous"> -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p"
        crossorigin="anonymous"></script> -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
  <!-- Include Bootstrap CSS -->
  <!-- <link href="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet"> -->
  <!-- <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js"
        integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script> -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
  <!-- Include jQuery -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <!-- Include Bootstrap Bundle with Popper -->
  <!-- <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.1.3/js/bootstrap.bundle.min.js"></script> -->
</head>

<body class="theme-1 quicksand">
  <div class="loader-bg">
    <div class="loader-track">
      <div class="loader-fill"></div>
    </div>
  </div>
  <!-- [ Pre-loader ] End -->
  <!-- [ auth-signup ] end -->
  <style>
    .hover-effect {
      font-size: 17px;
      transition: transform 0.3s ease-in-out;
    }

    .hover-effect:hover {
      transform: scale(1.2);
    }

    .top-header-section {
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      z-index: 9999;
      height: 70px;
      background: #FFFFFF;
      width: 100%;
      display: flex;
      box-shadow: 0 3px 10px rgb(0 0 0 / 0.2);
    }

    nav.dash-sidebar.light-sidebar {
      top: 70px !important;
      left: 0 !important;
      border-radius: 0 !important;
      max-width: 230px;
    }

    .dash-container {
      margin-left: 225px;
      margin-right: 0;
    }

    .dash-item.active>.dash-link {
      background: linear-gradient(141.55deg, #0CAF60 3.46%, #0CAF60 99.86%), #0CAF60;
      color: #fff !important;
      box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
      border-radius: 12px;
      font-weight: 700;
    }

    .dash-container .dash-content {
      padding-left: 30px;
      padding-right: 24px;
      padding-top: 30px;
    }

    .dash-item>.dash-link:hover {
      background: linear-gradient(141.55deg, #0CAF60 3.46%, #0CAF60 99.86%), #0CAF60;
      color: #fff !important;
      box-shadow: 0 5px 7px -1px rgba(12, 175, 96, 0.3);
      border-radius: 12px;
      font-weight: 700;
    }

    .dash-item:hover i {
      color: #0CAF60 !important;
    }

    .dash-item.active>.dash-link i {
      color: #0CAF60 !important;
    }

    .accordion {
      padding: 7px 10px 7px 7px;
    }

    .accordion-body {
      padding: 1rem;
    }

    .mx-70 {
      min-width: 70%;
    }

    .form-control-search {
      background: #eee;
    }

    .dropdown .dropdown-menu {
      min-width: 190px;
    }

    #progressbar {
      margin-bottom: 0.5rem;
      overflow: hidden;
      color: lightgrey;
      padding: 5px;
      margin: 0;
    }

    .ai-assist {
      background: #0caf60;
      z-index: 99999;
      position: absolute;
      right: 0;
      width: 50px;
      height: 50px;
      border-radius: 50%;
      display: flex;
      align-items: center;
      justify-content: center;
      bottom: 20px;
      right: 10px;
      text-decoration: none;
      font-size: 18px;
      cursor: pointer;
      position: fixed;
      box-shadow: 2px 2px 3px #999;

    }

    .ai-assist:hover i {
      transform: scale(1.2);
      transition: all 0.2s ease
    }

    .ai-assist i {
      color: #fff;
    }

    #progressbar .active {
      color: #010046;
    }

    #progressbar li {
      list-style-type: none;
      font-size: 15px;
      width: 20%;
      float: left;
      position: relative;
      font-weight: 400
    }

    #progressbar #account:before {
      font-family: FontAwesome;
      content: "\e542"
    }

    #progressbar #personal:before {
      font-family: FontAwesome;
      content: "\f688"
    }

    #progressbar #payment:before {
      font-family: FontAwesome;
      content: "\f2b5"
    }

    #progressbar #confirm:before {
      font-family: FontAwesome;
      content: "\f00c"
    }

    #progressbar #followUp:before {
      font-family: FontAwesome;
      content: "\f017"
    }

    #progressbar li:before {
      width: 40px;
      height: 40px;
      line-height: 38px;
      display: block;
      font-size: 15px;
      color: #ffffff;
      background: lightgray;
      border-radius: 50%;
      margin: 0 auto 0 auto;
      padding: 2px;
      position: relative;
      z-index: 1;
    }

    #progressbar li:after {
      content: '';
      width: 100%;
      height: 2px;
      background: lightgray;
      position: absolute;
      left: 0;
      top: 20px;
      z-index: 0;
    }

    #progressbar li.active:before,
    #progressbar li.active:after {
      background: #0caf60;
    }

    .progress {
      height: 20px
    }

    .btn {
      font-size: 13px;
    }

    .btn i {
      font-size: 13px;
    }

    .progress-bar {
      background-color: #673AB7
    }

    .fit-image {
      width: 100%;
      object-fit: cover
    }

    .main-menu ul li {
      list-style-type: none;

    }

    .user-section {
      display: flex;
      flex-direction: column;
      padding: 5px 5px;
      border: 1px solid #00800057;
      border-radius: 6px;
    }

    .user-section span i {
      color: #0caf60;
      padding-right: 2px;
    }

    .search-span {
      display: flex;
      align-items: center;
      justify-content: center;
      height: 100%;
      background: green;
      position: absolute;
      right: 0;
      background: #0caf60;
      padding: 10px;
      border-radius: 0 .25rem .25rem 0;
      color: #fff;
    }

    .search-span i {
      color: #fff;
    }

    .tr-20 {
      min-width: 20%;
      max-width: 20%;
      list-style: none;
      border-right: 4px solid #fff;
      font-weight: 600;
      padding: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 600;
      background: linear-gradient(to right, #010046 50%, #eee 50%);
      background-size: 200% 100%;
      background-position: right bottom;
      transition: all .4s ease-out;
    }

    .tr-20:hover {
      cursor: pointer;
      background-position: left bottom;
      color: #fff;

    }

    .nav-tabs .active {
      background-color: #010046 !important;
      color: #fff !important;
      background-position: left bottom !important;
    }


    .btn-active {
      background: #010046 !important;
    }

    .br-none {
      border-right: none !important;
    }

    .right-nav-fixed {
      position: fixed;
      right: 0;
      top: 150px;
      z-index: 9999;
      gap: 5px;
      display: flex;
      flex-direction: column;
    }

    .tr-bg-sidenav-item {
      color: #fff;
      padding: 10px;
      background: #010046;
      min-width: 150px;
      max-width: 150px;
      position: relative;
      left: 115px;
      -webkit-transition: all .5s ease-in-out;
      -moz-transition: all .5s ease-in-out;
      -ms-transition: all .5s ease-in-out;
      -o-transition: all .5s ease-in-out;
      transition: all .5s ease-in-out;
    }

    .tr-bg-sidenav-item:hover {
      left: 0;
      cursor: pointer;
    }

    .dash-sidebar .dash-micon {
      width: 22px;
      height: 22px;
      margin-right: 10px;
    }

    .dash-sidebar .dash-micon i {
      font-size: 12px !important;
    }

    .dash-sidebar .dash-link {
      display: flex;
      flex-wrap: wrap;
      padding: 10px 20px;
    }

    .notification-icon {
      padding: 5px 10px;
      background: #fff;
      font-size: 26px;
    }

    .notification-icon i {
      color: #ff2929;
    }

    .notification-icon span {
      width: 20px;
      height: 20px;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #fff;
      color: red;
      font-size: 12px;
      border-radius: 50%;
      position: absolute;
      top: 2px;
      left: 18px;
      font-weight: 600;
    }
  </style>
  <script>
    const offers = document.querySelectorAll('.offer-text');
    let currentIndex = 0;

    function showNextOffer() {
      offers[currentIndex].style.display = 'none';
      currentIndex = (currentIndex + 1) % offers.length;
      offers[currentIndex].style.display = 'block';
    }
    offers[currentIndex].style.display = 'block';
    setInterval(showNextOffer, 4000);

    document.addEventListener('DOMContentLoaded', () => {
      const currentPage = window.location.pathname.split('/').pop(); // Get the current page name
      const links = document.querySelectorAll('.dash-link');

      links.forEach(link => {
        if (link.getAttribute('href') === currentPage) {
          link.parentElement.classList.add('active'); // Highlight the current item
          const accordionBody = link.closest('.accordion-collapse');
          if (accordionBody) {
            accordionBody.classList.add('show'); // Keep the dropdown open
          }
        }
      });
    })
  </script>
  <?php if(auth()->guard()->check()): ?>
  <a title="AI ASSIST" class="ai-assist">
    <i class="fa-regular fa-comment-dots"></i>
  </a>
  <div class="top-header-section d-flex align-items-center justify-content-between px-2">
    <img src="/public/assets/img/trust-logo.png" alt="trust-logo" class="tr-trust-logo" style="margin-left: 20px;max-width: 120px;">
    <div>
      <img src="/public/assets/img/Sales.svg" class="tr-w-200">
    </div>
    <div class="logout-icon d-flex align-items-center gap-3">
      <div class="notification-icon position-relative">
        <i class="fa-solid fa-bell"></i>
        <span>10</span>
      </div>
      <div class="d-flex align-items-center gap-2">
        <img src="/public/assets/img/team/profile-picture-1.jpg" style="width:30px;border-radius:50%">
        <div class="dropdown">
          <button class="dropdown-toggle" type="button" id="username-section" data-bs-toggle="dropdown" aria-expanded="false" style="border:none;background:transparent;font-weight: 600; font-size: 16px;">
            Madhu K
          </button>
          <ul class="dropdown-menu" aria-labelledby="username-section">
            <li>
              <a class="dropdown-item" href="#">
                <form action="<?php echo e(route('logoutprofile')); ?>" method="post" style="display: inline;"> <?php echo csrf_field(); ?> <button class="d-flex gap-2 align-items-center justify-content-center" type="submit" style="border:none;background: none;font-weight: 600;">
                    <i class="fa-solid fa-right-from-bracket" style="color:#ff4900"></i> Logout </button>
                </form>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <nav class="dash-sidebar light-sidebar " style="bottom: 0;">
    <div class="navbar-wrapper">
      <div class="navbar-content">
        <ul class="dash-navbar">
          <li>
            <div class="accordion" id="accordionExample">
              <div class="accordion-item">
                <h2 class="accordion-header">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse"
                    data-bs-target="#collapseOneHeading" aria-expanded="true" aria-controls="collapseOneHeading">
                    Sales </button>
                </h2>
                <div id="collapseOneHeading" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                  <div style="padding-left: 0.5rem;" class="accordion-body">
                    <ul>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('lead.index')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-cart-shopping"></i>
                          </span>
                          <span class="dash-mtext"> My Leads</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('opportunity.index')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Opportunity</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('account.index')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-cart-shopping"></i>
                          </span>
                          <span class="dash-mtext"> My Accounts</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('contact.index')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Contacts</span>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
              <div class="accordion-item id=">
                <h2 class="accordion-header">
                  <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseCustomerHeading"
                    aria-expanded="true" aria-controls="collapseCustomerHeading"> Work </button>
                </h2>
                <div id="collapseCustomerHeading" class="accordion-collapse show" data-bs-parent="#accordionExample">
                  <div style="padding-left: 0.5rem;" class="accordion-body">

                    <ul>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.dashboard')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-sharp-duotone fa-regular fa-grid-horizontal"></i>
                          </span>
                          <span class="dash-mtext">My Dashboard</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_travel_expenses')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Q. Approvals</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_sales')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Sales</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_ageing_receivables')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext"> My Ledger</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_tourplan')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Tour Plan</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_dcr')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-sharp-duotone fa-regular fa-list"></i>
                          </span>
                          <span class="dash-mtext">My DCR</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_approvals')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Expenses</span>
                        </a>
                      </li>

                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_team')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Team</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_tasks')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-cart-shopping"></i>
                          </span>
                          <span class="dash-mtext"> My Activities</span>
                        </a>
                      </li>
                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_calender')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-calendar-days"></i>
                          </span>
                          <span class="dash-mtext">My Calendar</span>
                        </a>
                      </li>



                      <li class="dash-item dash-hasmenu">
                        <a href="<?php echo e(route('mydata.my_messages')); ?>" class="dash-link">
                          <span class="dash-micon">
                            <i class="fa-solid fa-timeline"></i>
                          </span>
                          <span class="dash-mtext">My Tickets</span>
                        </a>
                      </li>


                    </ul>
                  </div>
                </div>
              </div>
              <h2 class="accordion-header">
                <button class="accordion-button no-toggle" type="button"> Settings </button>
              </h2>
              <h2 class="accordion-header">
                <button class="accordion-button no-toggle" type="button">
                  <a href="<?php echo e(route('mydata.broadcast')); ?>">
                    <!-- <span class="dash-micon">
                      <i class="fa-solid fa-timeline"></i>
                    </span> -->
                    <span>Broadcast</span>
                  </a>
                </button>
              </h2>
              <h2 class="accordion-header">
                <button class="accordion-button no-toggle" type="button">

                  <a href="<?php echo e(route('mydata.forecast')); ?>">
                    <!-- <span class="dash-micon">
                      <i class="fa-solid fa-timeline"></i>
                    </span> -->
                    <span>Forecast</span>
                  </a>
                </button>
              </h2>
              <h2 class="accordion-header">
                <button class="accordion-button no-toggle" type="button">

                  <a href="<?php echo e(route('mydata.marketing')); ?>">
                    <!-- <span class="dash-micon">
                      <i class="fa-solid fa-timeline"></i>
                    </span> -->
                    <span>Marketing</span>
                  </a>
                </button>
              </h2>
              <h2 class="accordion-header">
                <button class="accordion-button no-toggle" type="button">

                  <a href="<?php echo e(route('mydata.globalcalendar')); ?>">
                    <!-- <span class="dash-micon">
                      <i class="fa-solid fa-timeline"></i>
                    </span> -->
                    <span>Global Calendar</span>
                  </a>
                </button>
              </h2>
            </div>
          </li>
          <!--             <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('lead.index')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-cart-shopping"></i>
                </span>
                <span class="dash-mtext">Leads</span>
              </a>
            </li>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('lead.create')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-user-group"></i>
                </span>
                <span class="dash-mtext">Lead Generation</span>
              </a>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('lead_tagging.index')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-location-arrow"></i>
                </span>
                <span class="dash-mtext">Lead Tagging</span>
              </a>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('opportunity.index')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-timeline"></i>
                </span>
                <span class="dash-mtext">Opportunity</span>
              </a>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('business.index')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-briefcase"></i>
                </span>
                <span class="dash-mtext">Business</span>
              </a>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="<?php echo e(route('salescall.index')); ?>" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-headset"></i>
                </span>
                <span class="dash-mtext">Sales Calls</span>
              </a>
            </li>
            <li class="dash-item dash-hasmenu">
              <a href="#!" class="dash-link">
                <span class="dash-micon">
                  <i class="fa-solid fa-layer-group"></i>
                </span>
                <span class="dash-mtext">Settings</span>
                <span class="dash-arrow">
                  <i data-feather="chevron-right"></i>
                </span>
              </a>
              <ul class="dash-submenu">
                <li class="dash-item">
                  <a href="<?php echo e(route('lead.profile')); ?>" class="dash-link">Profile </span>
                  </a>
                </li>
                <li class="dash-item">
                  <a href="<?php echo e(route('sales_headquarters.index')); ?>" class="dash-link">Sales HeadQuarters </span>
                  </a>
                </li>
              </ul>
            </li> -->
        </ul>
      </div>
    </div>
  </nav>
  <main style="margin-top: 70px;">
    <?php if(!isset($is_my_data_page) ): ?>

    <?php if(!isset($is_sales_module)): ?>
    <div class="right-nav-fixed">
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#dashboardModal">
        <!-- <a href="/lead/dashboard"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-house"></i> Dashboard </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#activityModal">
        <!-- <a href="/lead/activity"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-regular fa-chart-bar"></i> Activity </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#relationshipModal">
        <!-- <a href="/lead/relationship"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-regular fa-handshake"></i> Relationship </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#documentModal">
        <!-- <a href="/lead/documents"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-regular fa-file"></i> Documents </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#marketingModal">
        <!-- <a href="/lead/marketing"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-book-open"></i> Ledger </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#ticketsModal">
        <!-- <a href="/lead/marketing"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-ticket"></i> Ticket </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#notesModal">
        <!-- <a href="/lead/notes"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-pencil"></i> Notes </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#pricebookModal">
        <!-- <a href="/lead/price-book"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-book"></i> Price Book </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#profitabilityModal">
        <!-- <a href="/lead/profitability"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-dollar-sign"></i> Profitability </span>
        <!-- </a> -->
      </div>
      <div class="tr-bg-sidenav-item" data-bs-toggle="modal" data-bs-target="#forecastModal">
        <!-- <a href="/lead/forecast"> -->
        <span class="d-flex align-items-center gap-3">
          <i class="fa-solid fa-signal"></i> Forecast </span>
        <!-- </a> -->
      </div>
    </div>
    <?php endif; ?>
    <div class="d-flex align-items-center justify-content-between gap-3 tr-second-nav px-3 py-2" id="new-second-nav">
      <?php if(!isset($is_sales_module)): ?>
      <div class="user-section">
        <span class="tr-username">
          <i class="far fa-user-circle"></i> Madhu </span>
      </div>
      <?php else: ?>

      <div class="user-section">
        <span class="tr-username">
          My Leads </span>
      </div>

      <?php endif; ?>
      <div class="d-flex gap-2 align-items-center flex-grow-2 justify-content-end">

        <?php if(!isset($is_sales_module)): ?>
        <div class="dropdown">
          <button class="btn btn-warning" type="button" id="submit-lead-form">
            Submit
          </button>

          <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
          <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
           <script>
            $(document).ready(function() {
                $('#submit-lead-form').on('click', function(e) {
                    e.preventDefault();

                    // Create FormData object for both the main lead form and the document form
                    var leadFormData = new FormData($('#lead-form')[0]); // Collecting data from lead form
                    var leadFormUpdateData = new FormData($('#lead-form-update')[0]);

                    var docFormData = new FormData($('#doc_form')[0]); // Collecting data from document form
                    var notesFormData = new FormData($('#notes_form')[0]);
                    var record_id = $('#record_id').val(); // Getting the record_id value from the hidden input

                    // Combine both FormData objects (appending the document form data to lead form data)
                    docFormData.forEach(function(value, key) {
                        leadFormData.append(key, value); // Append document data (e.g., doc_file and doc_notes) to lead form
                    });

                    notesFormData.forEach(function(value, key) {
                        leadFormData.append(key, value); // Append document data (e.g., doc_file and doc_notes) to lead form
                    });

                    // Check if record_id exists to determine whether to create or update the lead
                    var url = (record_id) ? '<?php echo e(route("lead.update", ":id")); ?>'.replace(':id', record_id) : '<?php echo e(route("lead.save")); ?>';

                    // Submit the form via Ajax
                    $.ajax({
                        url: url, // Use the appropriate URL based on whether it's create or update
                        type: 'POST',
                        data: leadFormData, // Use combined FormData
                        processData: false, // Prevent jQuery from automatically transforming the data
                        contentType: false, // Prevent jQuery from setting the Content-Type
                        success: function(response) {
                            alert('Form submitted successfully!');
                            console.log(response);
                            window.location.reload(); // Reloads the current page
                        },
                        error: function(xhr) {
                            if (xhr.status === 422) {
                                let errors = xhr.responseJSON.errors;
                                for (const key in errors) {
                                    // Display errors below the relevant input
                                    $(`#${key}`).addClass('is-invalid'); // Bootstrap invalid class
                                    $(`#${key}`).after(`<div class="text-danger small">${errors[key][0]}</div>`);
                                }
                            } else {
                                alert('An error occurred. Please try again.');
                            }
                        },
                    });
                });
            });
        </script>


          <button class="btn btn-warning dropdown-toggle" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false"> Create </button>
          <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
            <li onclick="openPopup('Create Quote')">
              <div class="dropdown-item">Price Quote</div>
            </li>
            <!-- <li>
              <a class="dropdown-item" href="#">Account</a>
            </li> -->
            <li>
              <a class="dropdown-item" href="#">Contact</a>
            </li>
          </ul>
        </div>
        <?php endif; ?>
        <div class="position-relative d-flex">
          <input class="form-control form-control-search me-2" type="search" placeholder="Search" aria-label="Search">
          <span class="search-span">
            <i class="fa-solid fa-magnifying-glass"></i>
          </span>
        </div>
      </div>
    </div>

    <?php if(!isset($is_sales_module)): ?>
    <div class="tr-triple-nav">
      <div class="row mx-0 justify-content-center">
        <div class="col-12 text-center p-0 mt-3 mb-2">
          <div class="card px-0 pt-2 pb-0 mt-1 mb-2">
            <form id="msform">
              <!-- progressbar -->
              <ul id="progressbar">
                <li class="active" id="account">
                  <strong>Lead</strong>
                </li>
                <li id="personal">
                  <strong>Qualifying</strong>
                </li>
                <li id="payment">
                  <strong>Opportunity</strong>
                </li>
                <li id="confirm">
                  <strong>Account</strong>
                </li>
                <li id="followUp">
                  <strong>Ongoing</strong>
                </li>
              </ul>
            </form>
          </div>
        </div>
      </div>
    </div>

    <div class="tr-triple-nav">
      <div class="row mx-0 main-menu nav nav-tabs" id="myTab" role="tablist">
        <div class="tr-20 active" id="tr-details-tab" data-bs-toggle="tab" data-bs-target="#business-details-tab" type="button" role="tab" aria-controls="profile" aria-selected="false">
          <li>Business Details</li>
        </div>
        <div class="tr-20" id="tr-profile-tab" data-bs-toggle="tab" data-bs-target="#business-needs-tab" type="button" role="tab" aria-controls="profile" aria-selected="false">
          <li>Needs & Preferences</li>
        </div>
        <div class="tr-20" id="tr-profile-tab" data-bs-toggle="tab" data-bs-target="#price-quotes-tab" type="button" role="tab" aria-controls="profile" aria-selected="false">
          <li> Price Quotes</li>
        </div>
        <div class="tr-20" id="tr-profile-tab" data-bs-toggle="tab" data-bs-target="#sales-tab" type="button" role="tab" aria-controls="profile" aria-selected="false">
          <li>Sales</li>
        </div>

        <div class="tr-20" id="tr-profile-tab" data-bs-toggle="tab" data-bs-target="#time-capsule-tab" type="button" role="tab" aria-controls="profile" aria-selected="false">
          <li>Time Capsule</li>
        </div>
      </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
  </main>
  <footer class="mt-5 dash-footer d-none">
    <div class="footer-wrapper">
      <div class="py-1"></div>
    </div>
  </footer>
  <div id="commonModal" class="modal" tabindex="-1" aria-labelledby="exampleModalLongTitle" aria-modal="true" role="dialog" data-keyboard="false" data-backdrop="static">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="body"></div>
      </div>
    </div>
  </div>
  <div class="modal fade" id="commonModalOver" tabindex="-1" role="dialog" aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLongTitle"></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="body"></div>
      </div>
    </div>
  </div>
  <div class="loader-wrapper d-none">
    <span class="site-loader"></span>
  </div>
  <div class="top-0 p-3 position-fixed end-0" style="z-index: 99999">
    <div id="liveToast" class="text-white toast fade" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body"></div>
        <button type="button" class="m-auto btn-close btn-close-white me-2" data-bs-dismiss="toast" aria-label="Close"></button>
      </div>
    </div>
  </div>
  <!-- <div><a data-bs-toggle="tooltip" data-bs-original-title="Buy Premium Add-on"
            href="https://workdo.io/product-category/dash-saas-addon?utm_source=demo&amp;utm_medium=dash&amp;utm_campaign=btn"
            target="_blank" class="add-on-add-icon"><img
                src="https://dash-demo.workdo.io/uploads/logo/workdo-shop.png"></a></div> -->
  <!-- Required Js -->
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/popper.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/perfect-scrollbar.min.js"></script>
  <!-- <script src="https://dash-demo.workdo.io/assets/js/plugins/bootstrap.min.js"></script> -->
  <script src="https://dash-demo.workdo.io/assets/js/plugins/feather.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/simplebar.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/dash.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/simple-datatables.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/bootstrap-switch-button.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/sweetalert2.all.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/datepicker-full.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/flatpickr.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/choices.min.js"></script>
  <script src="https://dash-demo.workdo.io/js/jquery.form.js"></script>
  <script src="https://dash-demo.workdo.io/js/custom.js"></script>
  <script>
    var scrollSpy = new bootstrap.ScrollSpy(document.body, {
      target: '#useradd-sidenav',
      offset: 300
    })
  </script>
  <script src="https://dash-demo.workdo.io/packages/workdo/Lead/src/Resources/assets/js/dropzone.min.js"></script>
  <script src="https://dash-demo.workdo.io/assets/js/plugins/summernote-0.8.18-dist/summernote-lite.min.js"></script>
  <script>
    Dropzone.autoDiscover = false;
    myDropzone2 = new Dropzone("#dropzonewidget2", {
      maxFiles: 20,
      maxFilesize: 20,
      parallelUploads: 1,
      acceptedFiles: ".jpeg,.jpg,.png,.pdf,.doc,.txt",
      url: "https://dash-demo.workdo.io/leads/839/file",
      success: function(file, response) {
        if (response.is_success) {
          dropzoneBtn(file, response);
        } else {
          myDropzone2.removeFile(file);
          toastrs('Error', response.error, 'error');
        }
      },
      error: function(file, response) {
        myDropzone2.removeFile(file);
        if (response.error) {
          toastrs('Error', response.error, 'error');
        } else {
          toastrs('Error', response, 'error');
        }
      }
    });
    myDropzone2.on("sending", function(file, xhr, formData) {
      formData.append("_token", $('meta[name="csrf-token"]').attr('content'));
      formData.append("lead_id", 839);
    });

    function dropzoneBtn(file, response) {
      var download = document.createElement('a');
      download.setAttribute('href', response.download);
      download.setAttribute('class', "btn btn-sm btn-primary m-1");
      download.setAttribute('data-toggle', "tooltip");
      download.setAttribute('download', file.name);
      download.setAttribute('data-original-title', "Download");
      download.innerHTML = " < i class = 'ti ti-download' > < /i>";
      var del = document.createElement('a');
      del.setAttribute('href', response.delete);
      del.setAttribute('class', "btn btn-sm btn-danger mx-1");
      del.setAttribute('data-toggle', "tooltip");
      del.setAttribute('data-original-title', "Delete");
      del.innerHTML = " < i class = 'ti ti-trash' > < /i>";
      del.addEventListener("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        if (confirm("Are you sure ?")) {
          var btn = $(this);
          $.ajax({
            url: btn.attr('href'),
            data: {
              _token: $('meta[name="csrf-token"]').attr('content')
            },
            type: 'DELETE',
            success: function(response) {
              if (response.is_success) {
                btn.closest('.dz-image-preview').remove();
                btn.closest('.dz-file-preview').remove();
                toastrs('Success', response.success, 'success');
              } else {
                toastrs('Error', response.error, 'error');
              }
            },
            error: function(response) {
              response = response.responseJSON;
              if (response.error) {
                toastrs('Error', response.error, 'error');
              } else {
                toastrs('Error', response, 'error');
              }
            }
          })
        }
      });
      var html = document.createElement('div');
      html.appendChild(download);
      html.appendChild(del);
      file.previewTemplate.appendChild(html);
    }
    $(document).on("click", ".task-checkbox", function() {
      var chbox = $(this);
      var lbl = chbox.parent().parent().find('label');
      $.ajax({
        url: chbox.attr('data-url'),
        data: {
          _token: $('meta[name="csrf-token"]').attr('content'),
          status: chbox.val()
        },
        type: 'PUT',
        success: function(response) {
          if (response.is_success) {
            chbox.val(response.status);
            if (response.status) {
              lbl.addClass('strike');
              lbl.find('.badge').removeClass('bg-warning').addClass('bg-success');
            } else {
              lbl.removeClass('strike');
              lbl.find('.badge').removeClass('bg-success').addClass('bg-warning');
            }
            lbl.find('.badge').html(response.status_label);
            toastrs('Success', response.success, 'success');
          } else {
            toastrs('Error', response.error, 'error');
          }
        },
        error: function(response) {
          response = response.responseJSON;
          if (response.is_success) {
            toastrs('Error', response.error, 'error');
          } else {
            toastrs('Error', response, 'error');
          }
        }
      })
    });
    $(document).ready(function() {
      var tab = 'general';
      $("#myTab2 .nav-link-tabs[href='#" + tab + "']").trigger("click");
    });
  </script>
  <script>
    $(document).ready(function() {
      $('.summernote').on('summernote.blur', function() {
        $.ajax({
          url: "https://dash-demo.workdo.io/leads/839/note",
          data: {
            _token: $('meta[name="csrf-token"]').attr('content'),
            notes: $(this).val()
          },
          type: 'POST',
          success: function(response) {
            if (response.is_success) {} else {
              toastrs('Error', response.error, 'error');
            }
          },
          error: function(response) {
            response = response.responseJSON;
            if (response.is_success) {
              toastrs('Error', response.error, 'error');
            } else {
              toastrs('Error', response, 'error');
            }
          }
        })
      });
    });
  </script>
  <script>
    if ($(".summernote").length > 0) {
      $('.summernote').summernote({
        toolbar: [
          ['style', ['style']],
          ['font', ['bold', 'italic', 'underline', 'strikethrough']],
          ['list', ['ul', 'ol', 'paragraph']],
          ['insert', ['link', 'unlink']],
        ],
        height: 230,
      });
    }
  </script>
  <script>
    document.querySelectorAll('.description-container').forEach(function(container) {
      container.addEventListener('click', function() {
        var shortDescription = container.querySelector('.shortDescription');
        var fullDescription = container.querySelector('.fullDescription');
        if (shortDescription.style.display === 'block' || shortDescription.style.display === '') {
          shortDescription.style.display = 'none';
          fullDescription.style.display = 'block';
        } else {
          shortDescription.style.display = 'block';
          fullDescription.style.display = 'none';
        }
      });
    });
  </script>
  <script>
    $(window).scroll(function() {
      if ($(window).scrollTop() >= 100) {
        $('#new-second-nav').addClass('fixed-header');
      } else {
        $('#new-second-nav').removeClass('fixed-header');
      }
    });
  </script>

  <div id="close" class="closeBtn" onclick="closePopup()">
    X
  </div>
  <div id="popup" class="popup">
    <div style="position: relative; height:95%">


      <div class="mb-4 my-activity-title" style="margin-top: 0.6rem;">
        <div style="font-size: 20px;" id='popupTitle'>Create Quote</div>

        <div class="d-flex" style="align-items: center;">
          <div class="dropdown activity-buttons">
            <button class="btn btn-warning me-2 dropdown-toggle" id="package" data-bs-toggle="dropdown" aria-expanded="false">Package</button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
              <li>
                <div onclick="showForm('existing','Package')" class="dropdown-item">Existing TDPL Package</div>
              </li>
              <li>
                <div onclick="showForm('new','Package')" class="dropdown-item">New Customised Package</div>
              </li>
            </ul>
          </div>
          <div class="dropdown activity-buttons">
            <button class="btn btn-warning me-2 dropdown-toggle" id="profile" data-bs-toggle="dropdown" aria-expanded="false">Profile</button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton1">
              <li>
                <div onclick="showForm('existing','Profile')" class="dropdown-item">Existing TDPL Profile</div>
              </li>
              <li>
                <div onclick="showForm('new','Profile')" class="dropdown-item">New Customised Profile</div>
              </li>
            </ul>
          </div>
          <div class="dropdown activity-buttons">
            <button onclick="showForm()" class="btn btn-warning me-2" id="quote-test">Test</button>
          </div>

        </div>
      </div>
      <div style="margin: 1rem;" id="create-quote">




      </div>
    </div>

    <div class="support-query-form-buttons">
      <button type="submit" class="support-query-save mb-3">Submit</button>
    </div>
  </div>


  </div>
  </div>
  <script>
    function showForm(option, Name) {
      const createQuoteDiv = document.getElementById('create-quote');
      // createQuoteDiv.style.display = "flex"
      if (option === 'existing') {
        // createQuoteDiv.classList.remove('create-quote');
        createQuoteDiv.innerHTML = `
        <h4>Existing  TDL ${Name}</h4>
           <table style="width: 100%;"  class="table table-bordered">
              <thead>
                <tr>
                  <th >S.No</th>
                  <th style="max-width: 4rem; white-space: break-spaces;" >Test Code</th>
                  <th style="min-width: 14rem;" >${Name} Name</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Parameters</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Current Quantity per Month</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Expected Quantity per Month</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Listed L2L Price</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Ideal L2L Price</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Requested L2L Price</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Total Revenue</th>
                  <!-- <th title="Action" width="60">Action</th> -->
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    1
                  </td>
                  <td>
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td class="location">
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                </tr>
              </tbody>
            </table>
            
<div style="float:inline-end;">
              <button style="float:inline-end; width: fit-content;" class="btn btn-primary mt-2 mb-3"><svg style="width: 22px; height:25px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4" />
          </svg></button>
          </div>`;
      } else if (option === 'new') {
        // createQuoteDiv.classList.add('create-quote');
        createQuoteDiv.innerHTML =

          `
     <h4>New Customised ${Name}</h4>
      <table style="width: 100%;"  class="table table-bordered">
              <thead>
                <tr>
                  <th >S.No</th>
                  <th  style="min-width: 14rem;" >Name Of ${Name}</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Parameters</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Requested L2L Price</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Expected ${Name} per Month</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Total Revenue</th>
                  <!-- <th title="Action" width="60">Action</th> -->
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    1
                  </td>
                  <td>
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td class="location">
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                 
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                    </td>
                </tr>
              </tbody>
            </table>
            
<div style="float:inline-end;">
              <button style="float:inline-end; width: fit-content;" class="btn btn-primary mt-2  mb-3"><svg style="width: 22px; height:25px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4" />
          </svg></button>
          </div>`;
      } else {
        createQuoteDiv.classList.remove('create-quote');
        createQuoteDiv.style.margin = '1rem'
        createQuoteDiv.innerHTML = `
         <h4>Test</h4>
       <table style="width: 100%;"  class="table table-bordered">
              <thead>
                <tr>
                  <th >S.No</th>
                  <th title="Test Code" style="max-width: 4rem; white-space: break-spaces;" >Test Code</th>
                  <th title="Test Name" style="min-width: 14rem;" >Test Name</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Method</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Expected Quantity per Month</th>
                  <th style="max-width: 4rem; white-space: break-spaces;" >Listed L2L Price</th>
                  <th style="max-width: 4rem; white-space: break-spaces;" >Ideal L2L Price</th>
                  <th style="max-width: 4rem; white-space: break-spaces;" >Requested L2L Price</th>
                  <th  style="max-width: 4rem; white-space: break-spaces;" >Total Revenue</th>
                  <!-- <th title="Action" width="60">Action</th> -->
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    1
                  </td>
                  <td>
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td class="location">
                    <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                 
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                    </td>
                 
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>  
                  <td> <input class='form-control ' type="text" class="form-control">
                  <td> <input class='form-control ' type="text" class="form-control">
                  </td>
                </tr>
              </tbody>
            </table>
            
<div style="float:inline-end;">
              <button style="float:inline-end; width: fit-content;" class="btn btn-primary mt-2  mb-3"><svg style="width: 22px; height:25px" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-plus" viewBox="0 0 16 16">
            <path d="M8 4a.5.5 0 0 1 .5.5v3h3a.5.5 0 0 1 0 1h-3v3a.5.5 0 0 1-1 0v-3h-3a.5.5 0 0 1 0-1h3v-3A.5.5 0 0 1 8 4" />
          </svg></button>
          </div>
            `
      }
    }

    function openPopup(name) {
      // Access the child element using its id
      const popupTitle = document.getElementById('popupTitle');

      // Change the text content
      popupTitle.textContent = name;

      document.getElementById('popup').classList.add('open');
      document.getElementById('close').classList.add('opened');
    }

    function closePopup() {
      document.getElementById('popup').classList.remove('open');
      document.getElementById('close').classList.remove('opened');

    }
  </script>
  <style>
    .create-quote {
      border: 1px solid #ccc;
      border-radius: 10px;
      box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
      background-color: #fff;
      overflow: hidden;
      margin: 0 0.5rem 0.5rem 0.5rem;
      padding: 0.5rem;
      transition: transform 0.3s ease;
    }

    .create-quote select {
      width: 50% !important;
    }

    .create-quote input {
      width: 50% !important;
    }

    .activity-buttons {
      align-items: center;
      display: flex;
    }

    .label-pakage {
      margin-right: 0.5rem;
    }

    .my-activity-title {
      background: #010046;
      color: white;
      height: 56px;
      border-radius: 4px;
      font-size: 32px;
      align-items: center;
      display: flex;
      justify-content: space-between;
      padding: 1rem;
    }

    .popup {

      overflow: auto;
      top: 50px;
      position: fixed;
      /* top: 0; */
      right: -100%;
      width: calc(100% - 265px);
      height: 90%;
      background: #f8f9fa;
      box-shadow: -2px 0px 5px rgba(0, 0, 0, 0.3);
      padding: 0 20px;
      transition: 0.5s ease;
      z-index: 10000;
    }

    .popup.open {
      right: 0;
      bottom: 0;
      margin: 20px 0 20px 20px;
    }

    .closeBtn {
      /* overflow: auto; */
      top: 52px;
      position: fixed;
      /* top: 0; */
      right: -100%;
      width: 30px;
      height: 30px;
      background: #ff2222;
      padding: 5px;
      transition: 0.5s ease;
      border-radius: 50% 0 0 50%;
      display: flex;
      align-items: center;
      justify-content: space-evenly;
      color: #f8f9fa;
      font-weight: 700;
      cursor: pointer;
      z-index: 10000;
    }

    .closeBtn.opened {
      right: calc(100% - 265px);
      top: 100px;
    }

    #popup input {
      border-radius: 0;
    }
  </style>

</body>

</html><?php /**PATH /home/u871169370/domains/lightslategray-cassowary-878735.hostingersite.com/public_html/resources/views/layouts/base.blade.php ENDPATH**/ ?>