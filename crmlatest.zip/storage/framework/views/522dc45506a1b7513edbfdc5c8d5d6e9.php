
<?php $__env->startSection('content'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u871169370/domains/lightslategray-cassowary-878735.hostingersite.com/public_html/resources/views/mydata/my-dashboard.blade.php ENDPATH**/ ?>