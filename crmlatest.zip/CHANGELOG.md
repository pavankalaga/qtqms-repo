# Change Log

## Version 1.0.0

### Added
- Volt Dashboard Free
- Login
- Register
- Profile edit
- Recover password

## Version 1.0.0
- Upgrade to Laravel 9.x
