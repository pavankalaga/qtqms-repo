<?php

use App\Http\Controllers\Admin\LeadController;
use App\Http\Controllers\Admin\LeadProfileController;
use App\Http\Controllers\Admin\LeadTaggingController;
use App\Http\Controllers\Admin\OpportunityController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\BusinessController;
use App\Http\Controllers\SalesCallController;
use App\Http\Controllers\MyDataController;
use App\Http\Controllers\SalesHeadQuarterController;
use App\Http\Controllers\SalesProfileController;
use App\Http\Livewire\AnalyticsTab;
use App\Http\Livewire\BootstrapTables;
use App\Http\Livewire\BusinessIntelligence;
use App\Http\Livewire\BusinessStatistics;
use App\Http\Livewire\BusinessTab;
use App\Http\Livewire\Components\Buttons;
use App\Http\Livewire\Components\Forms;
use App\Http\Livewire\Components\Modals;
use App\Http\Livewire\Components\Notifications;
use App\Http\Livewire\Components\Typography;
use App\Http\Livewire\ContactDetails;
use App\Http\Livewire\Dashboard;
use App\Http\Livewire\Err404;
use App\Http\Livewire\Err500;
use App\Http\Livewire\LeadTagging;
use App\Http\Livewire\Opportunity;
use App\Http\Livewire\Remarks;
use App\Http\Livewire\ResetPassword;
use App\Http\Livewire\ForgotPassword;
use App\Http\Livewire\Lock;
use App\Http\Livewire\Auth\Login;
use App\Http\Livewire\Profile;
use App\Http\Livewire\Auth\Register;
use App\Http\Livewire\ForgotPasswordExample;
use App\Http\Livewire\Index;
use App\Http\Livewire\LoginExample;
use App\Http\Livewire\ProfileExample;
use App\Http\Livewire\RegisterExample;
use App\Http\Livewire\SalesCallLog;
use App\Http\Livewire\SalesCallTab;
use App\Http\Livewire\SalesFunnel;
use App\Http\Livewire\SalesHeadQuarters;
use App\Http\Livewire\SalesProfile;
use App\Http\Livewire\SearchReports;
use App\Http\Livewire\Transactions;
use App\Http\Livewire\ViewLeadRecord;
use Illuminate\Support\Facades\Route;
use App\Http\Livewire\ResetPasswordExample;
use App\Http\Livewire\UpgradeToPro;
use App\Http\Livewire\Users;
use App\Http\Livewire\Reports;
use App\Http\Livewire\EditReport;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\RoleController;
use App\Http\Livewire\BusinessInfo;
use App\Http\Livewire\EditBusinessInfo;





/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::redirect('/', '/login');

Route::get('/register', Register::class)->name('register');
Route::get('/login', [AuthController::class, 'index'])->name('login');
Route::post('/login', [AuthController::class, 'store'])->name('login.attempt'); // Changed name here
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/forgot-password', ForgotPassword::class)->name('forgot-password');

Route::get('/reset-password/{id}', ResetPassword::class)->name('reset-password')->middleware('signed');

Route::get('/404', Err404::class)->name('404');
Route::get('/500', Err500::class)->name('500');
Route::get('/upgrade-to-pro', UpgradeToPro::class)->name('upgrade-to-pro');



Route::middleware('auth')->group(callback: function () {
    Route::post('/logoutprofile', [AuthController::class, 'logout'])->name('logoutprofile');
    Route::get('/lead', [LeadController::class, 'index'])->name('lead.index');
    Route::get('/lead/data', [LeadController::class, 'getReports'])->name('lead.data');
    Route::get('/leadtagging/data', [LeadTaggingController::class, 'getReports'])->name('leadtagging.data');
    Route::get('/lead/create', [LeadController::class, 'create'])->name('lead.create');
    Route::get('/lead/view/{id}', [LeadController::class, 'view'])->name('lead.view');
    Route::get('/lead/edit/{id}', [LeadController::class, 'edit'])->name('lead.edit');
    Route::post('/lead/update/{id}', [LeadController::class, 'update'])->name('lead.update');
    Route::get('/lead/marketing', [LeadController::class, 'marketing'])->name('lead.marketing');
    Route::get('/lead/forecast', [LeadController::class, 'forecast'])->name('lead.forecast');
    Route::get('/lead/relationship', [LeadController::class, 'relationship'])->name('lead.relationship');
    Route::get('/lead/quotes', [LeadController::class, 'quotes'])->name('lead.quotes');
    Route::get('/lead/profitability', [LeadController::class, 'profitability'])->name('lead.profitability');
    Route::get('/lead/price-book', [LeadController::class, 'pricebook'])->name('lead.pricebook');
    Route::get('/lead/notes', [LeadController::class, 'notes'])->name('lead.notes');
    Route::get('/lead/activity', [LeadController::class, 'my_activity'])->name('lead.notes');
    Route::get('/lead/my-expenses', [LeadController::class, 'my_expenses'])->name('lead.notes');
    Route::get('/lead/my-dcr', [LeadController::class, 'my_dcr'])->name('lead.dcr');
    Route::get('/lead/my-approvals', [LeadController::class, 'my_approvals'])->name('lead.my_expenses');
    Route::get('/lead/documents', [LeadController::class, 'documents'])->name('lead.documents');
    Route::get('/lead/my-tasks', [LeadController::class, 'my_tasks'])->name('lead.tasks');
    Route::get('/my-accounts', [LeadController::class, 'my_accounts'])->name('account.index');
Route::get('/my-contacts', [LeadController::class, 'my_contacts'])->name('contact.index');
    // Route::get('/lead/marketing', [LeadController::class, 'edit'])->name('lead.edit');
    

    Route::post('/lead/businessfinfoupdate/{id}', [LeadController::class, 'businessfinfoupdate'])->name('lead.businessfinfoupdate');
    Route::post('/lead/BusinessInteligence/{id}', [LeadController::class, 'BusinessInteligence'])->name('lead.BusinessInteligence');
    Route::post('/lead/remark/{id}', [LeadController::class, 'remark'])->name('lead.remark');
    Route::delete('/lead/delete/{id}', [LeadController::class, 'delete'])->name('lead.delete');
    Route::post('/lead/add_contacts/{lead_id}', [LeadController::class, 'addContactDetails'])->name('lead.add.contacts');
    Route::delete('/contact_delete/{id}', [LeadController::class, 'contactDestroy'])->name('lead.contaact_delete');
    Route::post('/lead/update_contacts', [LeadController::class, 'updateContactDetails'])->name('lead.update.contact');

    Route::get('/lead-tagging', [LeadTaggingController::class, 'index'])->name('lead_tagging.index');
    Route::get('/lead/example-company', [LeadTaggingController::class, 'example_company'])->name('lead_tagging.ex');
    
    Route::get('/leadprofiles', [LeadProfileController::class, 'index'])->name('lead.profile');
    Route::get('/leadprofiles/data', [LeadProfileController::class, 'getProfiles'])->name('lead.getprofile');
    Route::get('/leads-profile', [LeadProfileController::class, 'create'])->name('lead.profile.create');
    Route::post('/lead-profile-store', [LeadProfileController::class, 'store'])->name('lead.profile.store');
    Route::get('/lead-profile-edit/{id}', [LeadProfileController::class, 'edit'])->name('lead.profile.edit');
    Route::get('/lead-profile-view/{id}', [LeadProfileController::class, 'view'])->name('lead.profile.view');
    Route::post('/lead-profile-update/{id}', [LeadProfileController::class, 'update'])->name('lead.profile.update');
    Route::delete('/lead/{id}', [LeadProfileController::class, 'destroy'])->name('lead.destroy');
    
    Route::post('/lead/{id}/assign_user', [LeadTaggingController::class, 'leadTagging'])->name('leads.assign_user');
    
    Route::get('/lead-opportunity', [OpportunityController::class, 'index'])->name('opportunity.index');
    Route::get('/lead-opportunity/data', [OpportunityController::class, 'getReports'])->name('opportunity.data');
    Route::post('savecalllogs',[OpportunityController::class,'saveCallLogs'])->name('savecalllog');
    Route::post('changestatus/{id}',[OpportunityController::class,'ChangeStatus'])->name('change_status');

    Route::get('/lead-business', [BusinessController::class, 'index'])->name('business.index');
    Route::get('/lead-business/data', [BusinessController::class, 'getReports'])->name('business.data');
    Route::get('/lead-statistics/{id}}', [BusinessController::class, 'businessStatisctics'])->name('lead.business_statistics');

    Route::get('/salescall', [SalesCallController::class, 'index'])->name('salescall.index');
    Route::get('/salescall/calllog', [SalesCallController::class, 'getCalllogs'])->name('salescall.calllog');
    Route::get('/salescall/data', [SalesCallController::class, 'getReports'])->name('salescall.data');
    Route::post('assign_day_plan' , [SalesCallController::class,'assignUsers'])->name('salescall.assign_users');

    Route::get('/sales_headquarters', action: [SalesHeadQuarterController::class,'index'])->name('sales_headquarters.index');
    Route::get('/sales_headquarters/data', [SalesHeadQuarterController::class, 'getReports'])->name('sales_headquarters.data');
    Route::post('/sales_headquarters/edit/{id}', action: [SalesHeadQuarterController::class,'edit'])->name('sales_headquarters.edit');

    Route::post('/sales_headquarters/save', action: [SalesHeadQuarterController::class,'save'])->name('sales_headquarters.save');
    Route::post('/sales_headquarters/update/{id}', action: [SalesHeadQuarterController::class,'update'])->name('sales_headquarters.update');
    Route::delete('/sales_headquarters/{id}', [SalesHeadQuarterController::class, 'destroy'])->name('sales_headquarters.destroy');



  // My Data Routes
     Route::get('/my-tasks', [MyDataController::class, 'my_tasks'])->name('mydata.my_tasks');
     Route::get('/my-calender', [MyDataController::class, 'my_calender'])->name('mydata.my_calender');
     Route::get('/my-tourplan', [MyDataController::class, 'my_tourplan'])->name('mydata.my_tourplan');
     Route::get('/my-travel-expenses', [MyDataController::class, 'my_travel_expenses'])->name('mydata.my_travel_expenses');
     Route::get('/my-sales', [MyDataController::class, 'my_sales'])->name('mydata.my_sales');
     Route::get('/marketing', [MyDataController::class, 'marketing'])->name('mydata.marketing');
     Route::get('/forecast', [MyDataController::class, 'forecast'])->name('mydata.forecast');
     Route::get('/broadcast', [MyDataController::class, 'broadcast'])->name('mydata.broadcast');
     Route::get('/my-messages', [MyDataController::class, 'my_messages'])->name('mydata.my_messages');
     Route::get('/my-team', [MyDataController::class, 'my_team'])->name('mydata.my_team');
     Route::get('/my-dcr', [MyDataController::class, 'my_dcr'])->name('mydata.my_dcr');
     Route::get('/my-dashboard', [MyDataController::class, 'my_dashboard'])->name('mydata.dashboard');
     Route::get('/my-approvals', [MyDataController::class, 'my_approvals'])->name('mydata.my_approvals');
     Route::get('/my-global-calander', [MyDataController::class, 'my_global_calander'])->name('mydata.globalcalendar');
     Route::get('/my-ageing-receivables', [MyDataController::class, 'my_ageing_receivables'])->name('mydata.my_ageing_receivables');


    Route::get('/role/{id}', [RoleController::class, 'show'])->name('role.show');
    Route::post('/lead/store', [LeadController::class, 'store'])->name('lead.save');
    Route::get('/admin/dashboard', SearchReports::class)->name('admin');
    Route::get('/reportlist', action: SearchReports::class)->name('reportlist');
    // Route::get('/business_info', action: BusinessInfo::class)->name('business_info');
    // Route::get('/business_info', action: BusinessInfo::class)->name('business_info');
    Route::get('/contact_details', action: ContactDetails::class)->name('contact_details');
    Route::get('/business_intelligence', action: BusinessIntelligence::class)->name('business_intelligence');
    Route::get('/business_info', action: Remarks::class)->name('business_info');
    Route::get('/edit_business_info/{id}', action: EditBusinessInfo::class)->name('business.info.edit');
    Route::get('/view_business_info/{id}', action: ViewLeadRecord::class)->name('business.info.view');
    // Route::get('/sales_headquarter', action: SalesHeadQuarters::class)->name('sales_headquarters');


    //Sales Funnel
    Route::get('/sales_funnel', action: SalesFunnel::class)->name('sales_funnel');
    Route::get('/business_statistics/{selectedId}', action: BusinessStatistics::class)->name('business_statistics');


    // sales Profile
    Route::get('/profile', [SalesProfileController::class, 'index'])->name('profile.index');
    Route::get('/crate-profile', [SalesProfileController::class, 'create'])->name('profile.create');
    Route::post('/store-profile', [SalesProfileController::class, 'store'])->name('profile.store');
    // In routes/web.php
    Route::get('/get-reported-roles/{role}', [SalesProfileController::class, 'getReportedRoles'])->name('getReportedRoles');



    Route::get('/sales_profile', SalesProfile::class)->name('sales_profile');
    Route::get('/lead_tagging', LeadTagging::class)->name('lead_tagging');
    Route::get('/opportunity', Opportunity::class)->name('opportunity');
    Route::get('/business', BusinessTab::class)->name('business');
    Route::get('/sales_call', SalesCallTab::class)->name('sales_call');
    Route::get('/analytics', AnalyticsTab::class)->name('analytics');
    Route::get('/call-logs', SalesCallLog::class)->name('call-log');

    Route::get('/profile-example', ProfileExample::class)->name('profile-example');
    Route::get('/users', Users::class)->name('users');
    Route::get('/login-example', LoginExample::class)->name('login-example');
    Route::get('/register-example', RegisterExample::class)->name('register-example');
    Route::get('/forgot-password-example', ForgotPasswordExample::class)->name('forgot-password-example');
    Route::get('/reset-password-example', ResetPasswordExample::class)->name('reset-password-example');
    Route::get('/transactions', Transactions::class)->name('transactions');
    Route::get('/reports', Reports::class)->name('reports');
    Route::get('/reports/edit/{id}', EditReport::class)->name('reports.edit');
    Route::get('/download-test-file', [Reports::class, 'download'])->name('download.testfile');
    Route::get('/bootstrap-tables', BootstrapTables::class)->name('bootstrap-tables');
    Route::get('/lock', Lock::class)->name('lock');
    Route::get('/buttons', Buttons::class)->name('buttons');
    Route::get('/notifications', Notifications::class)->name('notifications');
    Route::get('/forms', Forms::class)->name('forms');
    Route::get('/modals', Modals::class)->name('modals');
    Route::get('/typography', Typography::class)->name('typography');

});
