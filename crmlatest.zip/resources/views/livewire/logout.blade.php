<div wire:click='logout' class="flex w-full">
    <span class="text-black flex items-center w-full text-white">
        Logout 
        <!-- <svg class="dropdown-icon text-danger w-6 h-6  log-out-icon" fill="#fff" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1"></path>
        </svg> -->
        <i class="fas fa-sign-out-alt ml-auto text-white mr-3"></i>
    </span>
</div>
