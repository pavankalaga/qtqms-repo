<div>
<div class="w-full flex gap-4 lg:flex-nowrap ">
                <div class="form-group   lg:w-1/2 w-full">
                    <label for="business_type" class="col-form-label text-nowrap">Business Type: </label>
                    <select id="business_type" name="business_type" class="form-control"
                        wire:model="business_type" required>
                        <option value="">Select Business Type</option>
                        <option value="Hospital">Hospital</option>
                        <option value="Diagnostic Center">Diagnostic Center</option>
                        <option value="Independent Doctor">Independent Doctor</option>
                        <option value="Registered Medical Practitioner">Registered Medical Practitioner</option>
                        <option value="Clinic">Clinic</option>
                        <option value="Clinical Research Business">Clinical Research Business</option>
                        <option value="Government Agency">Government Agency</option>
                    </select>
                    @error('business_type') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="form-group   lg:w-1/2 w-full">
                    <label for="legal_business_type" class="col-form-label text-nowrap">Legal Business Type: </label>
                    <select id="legal_business_type" name="legal_business_type" class="form-control"
                        wire:model="legal_business_type" required>
                        <option value="">Select Legal Business Type</option>
                        <option value="Incorporated">Incorporated</option>
                        <option value="Partnership">Partnership</option>
                        <option value="LLP">LLP</option>
                        <option value="Sole Proprietor">Sole Proprietor</option>
                    </select>
                    @error('legal_business_type') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="w-full flex gap-4 lg:flex-nowrap">

                <div class="flex flex-col lg:w-1/2 w-full">
                    <label for="business_name" class="col-form-label text-nowrap">Business
                        Name: </label>
                    <div class="flex-grow">
                        <input type="text"
                            class="w-full p-2 border border-gray-300 rounded-md placeholder-gray-500 text-sm"
                            id="business_name" name="business_name" placeholder="Enter Your Business Name"
                            wire:model="business_name" required>
                        @error('business_name')
                        <span class="text-red-600 text-sm">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

                <div class="flex flex-col lg:w-1/2 w-full">
                    <label for="registered_no"
                        class="col-form-label text-nowrap">Registered No: </label>
                    <div class="flex-grow">
                        <input type="text"
                            class="w-full p-2 border border-gray-300 rounded-md placeholder-gray-500 text-sm"
                            id="registered_no" placeholder="Enter Your Registered No" wire:model="registered_no"
                            required>
                        @error('registered_no')
                        <span class="text-red-600 text-sm">{{ $message }}</span>
                        @enderror
                    </div>
                </div>

            </div>




            <div class="flex lg:flex-nowrap  gap-4">

                <div class="w-full lg:w-1/2">
                    <label for="incorporation_date" class="col-form-label text-nowrap">Incorporation
                        Date:</label>
                    <input type="date" id="incorporation_date"
                        class="mt-1 block w-full p-2 border border-gray-300 rounded-md text-sm"
                        wire:model="incorporation_date" required>
                    @error('incorporation_date')
                    <span class="text-red-600 text-sm">{{ $message }}</span>
                    @enderror
                </div>

                <div class="w-full lg:w-1/2">
                    <label for="incorporation_no" class="col-form-label text-nowrap">Inc No:</label>
                    <input type="number" id="incorporation_no" placeholder="Enter Your Inc No"
                        class="mt-1 block w-full p-2 border border-gray-300 rounded-md text-sm"
                        wire:model="incorporation_no" required>
                    @error('incorporation_no')
                    <span class="text-red-600 text-sm">{{ $message }}</span>
                    @enderror
                </div>

            </div>


            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="pan_no" class="col-form-label">PAN No:</label>
                    <input type="text" class="form-control small-placeholder" id="pan_no"
                        placeholder="Enter Your PAN No" wire:model="pan_no" required>
                    @error('pan_no') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="w-full lg:w-1/2">
                    <label for="tan_no" class="col-form-label">TAN No:</label>
                    <input type="text" class="form-control small-placeholder" id="tan_no"
                        placeholder="Enter Your TAN No" wire:model="tan_no" required>
                    @error('tan_no') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="country" class="col-form-label">Country: </label>
                    <input type="text" class="form-control small-placeholder" id="country" placeholder="Country"
                        wire:model="country" required>
                    @error('country') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="w-full lg:w-1/2">
                    <label for="state" class="col-form-label">State: </label>
                    <input type="text" class="form-control small-placeholder" id="state" placeholder="State"
                        wire:model="state" required>
                    @error('state') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
               
            </div>



            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="city" class="col-form-label">City: </label>
                    <input type="text" class="form-control small-placeholder" id="city" placeholder="City"
                        wire:model="city" required>
                    @error('city') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="w-full lg:w-1/2">
                    <label for="pincode" class="col-form-label">Sales HeadQuarters: </label>
                    <select wire:model="salesheadquarter" class="form-select "  required>
                        <option selected>Choose...</option>
                        @foreach ($sales_head_quarters as $sales)
                            <option value="{{ $sales->id }}">{{ $sales->name }}</option>
                        @endforeach
                    </select>
                    @error('pincode') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="phone" class="col-form-label">Phone: </label>
                    <input type="number" class="form-control small-placeholder" id="phone"
                        placeholder="Enter Your Phone Number" wire:model="phone" minlength="10" maxlength="10"
                        required />
                    @error('phone') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="w-full lg:w-1/2">
                    <label for="pincode" class="col-form-label">Pincode: </label>
                    <input type="number" class="form-control small-placeholder" id="pincode" placeholder="Pincode"
                        wire:model="pincode" minlength="6" maxlength="6" required>
                    @error('pincode') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="email" class="col-form-label">Email: </label>
                    <input type="email" class="form-control small-placeholder" id="email" placeholder="Enter Your Email"
                        wire:model="email" required />
                    @error('email') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
                <div class="w-full lg:w-1/2">
                    <label for="alternate_phone" class="col-form-label">Alternative Phone: </label>
                    <input type="number" class="form-control small-placeholder" id="alternate_phone"
                        placeholder="Alternate Phone" wire:model="alternate_phone" minlength="10" maxlength="10"
                        required>
                    @error('alternate_phone') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>

            <div class="flex lg:flex-nowrap  gap-4">
                <div class="w-full lg:w-1/2">
                    <label for="website" class="col-form-label">Website: </label>
                    <input type="text" class="form-control small-placeholder" id="website" placeholder="Website"
                        wire:model="website" required>
                    @error('website') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>

                <div class="w-full lg:w-1/2">
                    <label for="alternative_email" class="col-form-label">Alternative Email: </label>
                    <input type="email" class="form-control small-placeholder" id="alternative_email"
                        placeholder="Enter Alternative Email" wire:model="alternative_email" required>
                    @error('alternative_email') <span class="text-danger small">{{ $message }}</span> @enderror
                </div>
            </div>


            <div class="w-full lg:w-1/2">
                <label for="address" class="col-form-label">Address: </label>
                <textarea type="text" class="form-control small-placeholder" id="address" placeholder="Address"
                    wire:model="address" required></textarea>
                @error('address') <span class="text-danger small">{{ $message }}</span> @enderror
            </div>
</div>