<div>
    <h3 class="p-3 display-4" style="display:inline">Adminstrator</h3>
    <div class="flex row border-secondary rounded-lg ml-3 justify-content-between">
     <span>
            <h5 class="p-3"> This is Administrator Dashboard</h5>
        </span>
        
    </div>
</div>