<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Err500 extends Component
{
    public function render()
    {
        return view('500');
    }
}
