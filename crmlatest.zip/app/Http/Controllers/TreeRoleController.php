<?php

namespace App\Http\Controllers;

use App\Models\TreeRole;
use Illuminate\Http\Request;

class TreeRoleController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(TreeRole $treeRole)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(TreeRole $treeRole)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, TreeRole $treeRole)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(TreeRole $treeRole)
    {
        //
    }
}
